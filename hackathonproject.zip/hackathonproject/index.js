process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
import express from "express";
import cors from "cors";
import generateTestsRoute from "./routes/generateTests.js";
import path from "path";
import { fileURLToPath } from "url";
import projectsRouter from "./routes/projects.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/generate-tests", generateTestsRoute);

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, "UI")));
app.use("/projects", projectsRouter);

app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname,"UI", "errorPage.html"));
});