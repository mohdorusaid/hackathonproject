import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const router = express.Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const projectsPath = path.join(__dirname, "../projects");

// 🔹 In-memory cache
let cachedProjects = null;
let lastLoadedTime = null;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// 🔹 Format folder name nicely
function formatProjectName(name) {
  return name
    .replace(/[_-]/g, " ")
    .replace(/\b\w/g, char => char.toUpperCase());
}

router.get("/", (req, res) => {
  try {
    const now = Date.now();

    // 🔹 Return cached if valid
    if (cachedProjects && (now - lastLoadedTime < CACHE_DURATION)) {
      return res.json({
        success: true,
        projects: cachedProjects
      });
    }

    const folders = fs.readdirSync(projectsPath)
      .filter(file =>
        fs.statSync(path.join(projectsPath, file)).isDirectory()
      )
      .map(folder => ({
        value: folder,                     // original folder name
        label: formatProjectName(folder)   // formatted display name
      }))
      .sort((a, b) => a.label.localeCompare(b.label));

    // 🔹 Cache result
    cachedProjects = folders;
    lastLoadedTime = now;

    res.json({
      success: true,
      projects: folders
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

export default router;
